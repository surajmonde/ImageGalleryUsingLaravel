<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
 //   return view('welcome');
//});
Route::view('/',"welcome");

Route::view('/register',"register");

Route::post('/postuserinfo',"PostUserInfoController@postuserinfo");

Route::view('/login',"login");

Route::post('/login',"PostUserInfoController@login");

Route::get('/dashboard',"PostUserInfoController@getempgallery");

//Route::view('/dashboard',"dashboard");



Route::post('/postimage',"PostUserInfoController@postimage");

Route::delete('/deleteimage/{photoid}',"PostUserInfoController@deleteimage");


Route::post('/logout',"PostUserInfoController@logout");

Route::view('/forgot',"forgot");

Route::post('/forgotpassword',"PostUserInfoController@forgotpassword");

Route::view('/changepassword',"changepassword");

Route::post('/changepassword',"PostUserInfoController@changepassword");
