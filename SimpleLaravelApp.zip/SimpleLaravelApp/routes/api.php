<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['prefix' => '/v1'],function(){
    
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization, If-Modified-Since, Cache-Control, Pragma");
    header('Content-Type: application/json;charset=utf-8');  
    header("Access-Control-Allow-Methods: GET, POST ,OPTIONS");    
    
        
        //********* User Request Services *****************/
        
        
        Route::post('app/post/createuser',[
            'uses' => 'PostUserInfoController@postuserinfo'
        ]);
        Route::post('app/post/forgotpassword',[
            'uses' => 'PostUserInfoController@forgotpassword'
        ]);
        Route::post('app/post/changepassword',[
            'uses' => 'PostUserInfoController@changepassword'
        ]);
        Route::post('app/post/postimage',[
            'uses' => 'PostUserInfoController@postimage'
        ]);
        
        Route::post('app/get/getempgallery',[
            'uses' => 'PostUserInfoController@getempgallery'
        ]);
        Route::post('app/get/token',[
            'uses' => 'PostUserInfoController@login'
        ]);

        Route::post('app/delete/deleteimage',[
            'uses' => 'PostUserInfoController@deleteimage'
        ]);
       

    });

/* Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user(); Web/userdetail 
}); */
