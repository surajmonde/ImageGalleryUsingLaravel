<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use JWTAuth;
use DB, Hash, Mail;
use DateTime;
use PHPExcel; 
use PHPExcel_IOFactory;
use PHPExcel_Style_Alignment;
use PHPExcel_Style_Border;
use PHPExcel_Style_Fill;
use PHPMailer\PHPMailer;
use PHPMailer\Exception;
use Session;
use Closure;
use Tymon\JWTAuth\Middleware\GetUserFromToken;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use Tymon\JWTAuth\Exceptions\JWTException;
use Carbon\Carbon;
use File;
use Image;
use App\ImageUpload;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;
use Auth;
date_default_timezone_set('Asia/Calcutta');

ignore_user_abort(true);
ob_start();

class PostUserInfoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $redirectTo = '/dashboard';
    protected $redirectToHOME = '/login';
    protected $redirectToChange = '/changepassword';
    
    public function index()
    {
        //
    }   
    public function postuserinfo(Request $request){
    try{

        $fullname = $request->input('emp_fullname');
        $username = $request->input('emp_username');
        $password = $request->input('password');
        $emailId = $request->input('emp_emailid');
       
        $check =  DB::connection('mysql')->table('employees')
        ->select('*')
        ->orWhere('username', $username)
        ->orWhere('emp_emailid', $emailId)
        ->orWhere('emp_fullname', $fullname)
        ->get();

         $num_rows = $check->count();
            if($num_rows>0){

                $response = [
                    'success'=> false,
                    'error' =>'Record Already Exist',
                ];
                return response()->json($response,201); 
               
            }
            else{ 
                $userId = DB::connection('mysql')->table('employees')->insertGetId(
                array('emp_fullname' => $fullname, 'username' => $username, 
                    'emp_emailid' =>  $emailId,
                    'password' => bcrypt($password)
                    ));   
                    return redirect()->intended($this->redirectToHOME);
                }            
        }
        catch(TokenInvalidException $e){
            $response = [
                'success'=> false,
                'token' =>'Token Invalid',
            ];
           return response()->json($response,402);    
        }
        catch (TokenExpiredException $e){

            $rows1['token']=false;//$rows['storename'];//storename
            $jsonData =(json_encode($rows1));
            
            $jsonData =(json_encode($rows1));
            echo '{';
            echo'"success": true,';
            echo '"data": [';
            echo $jsonData;
            echo ']';
            echo '}';       
        }
        catch(JWTException $e){
            $response = [
                'success'=> false,
                'token' =>'Data Not Found',
            ];
            return response()->json($response,405); 
        }        

    }

   
    public function login(Request $request)
    {     
        $credentials = $request->only('username','password');
        try{
            //Check record is already exist or not.
            $username =$request->input('username');
            $password =$request->input('password');
          
            
            if(empty($username)&&empty($password)){

                $message='Field are empty';
                $response = [
                    'success'=> false,
                    'error' =>$message,
                ];
                return response()->json($response,200);   

            }else{
                        
                    if(!$token = JWTAuth::attempt($credentials)){
                    $message='error2';
                    $response = [
                    'success'=> false,
                    'error' =>'incorrect username or password',
                        ];
                        return response()->json($response,200);   
                    }
                    else{
                                         
                       echo "Hi $username you logged in successfully welcome to Dashboard Page";
                       $result = DB::table('employees')
                       ->select('emp_id')
                       ->where('username', $username)
                       ->get();
                       foreach($result as $rowdt) {
                        $emp_id = $rowdt->emp_id;

                       }
                       Session::put('emp_id', $emp_id);

                        echo "Hi $emp_id your Emp id";
                       return redirect()->intended($this->redirectTo);
                    }                 

                }  
            
        } 
        catch(JWTException $e){
            return response()->json(['msg' => 'could not create token'],500);
        } 
    }

    public function logout(Request $request) {
        
        Auth::logout();
        return redirect('/login');
      }
    
   public function changepassword(Request $request){

    $token =$request->input('token');
    $emp_emailid =$request->input('emp_emailid');
    $newpassword =$request->input('newpassword');
    $tokenmatch='EMPTY';
    
    $sql = DB::table('employees')
    ->select('*')
    ->where([['emp_emailid', $emp_emailid]])
    ->get();
    $num_rowscount = $sql->count();   
    if($num_rowscount > 0) {
        
        foreach($sql as $rowdt) {
            $tokenmatch = $rowdt->token;
        }
        if($tokenmatch==$token){
             $sql = DB::table('employees')
            ->where([['emp_emailid', $emp_emailid]])
            ->update(
                array( 'password' => bcrypt($newpassword),
                       'token' => '',
                    ));
           // ->update(['password' => bcrypt($newpassword)]);

            $result1 = DB::table('employees')
            ->select('emp_id','emp_fullname','emp_emailid')
            ->where([['emp_emailid', $emp_emailid]])
            ->get();
           
            $jsonData =(json_encode($result1));
            echo '{';
            echo'"success": true,';
            echo '"data":';
            echo $jsonData;
            //echo '';
            echo '}';
            return redirect()->intended($this->redirectToHOME);
        }else{
            echo '{';
                echo '"success": false,';
                echo '"error": {';
                echo '"warning": "Token does not matach"';
                
                echo '}';
                echo '}'; 
        }

    }else{

    }

   }

   public function forgotpassword(Request $request){

       $emailid =$request->input('emp_emailid');
       $currentTime = date('Y-m-d H:i:s');
            $sql = DB::table('employees')
            ->select('*')
            ->where([['emp_emailid', $emailid]])
            ->get();
            $num_rowscount = $sql->count();    
		if($num_rowscount > 0) {
            $newpassword=$this->randomPassword();
           // echo $newpassword;
            $sql = DB::table('employees')
            ->where([['emp_emailid', $emailid]])
            ->update(['token' => $newpassword]);
            $emp_fullname='';
            $result1 = DB::table('employees')
            ->select('emp_id','emp_fullname','emp_emailid')
            ->where([['emp_emailid', $emailid]])
            ->get();
            foreach($result1 as $rowdt) {    
                $emp_fullname = $rowdt->emp_fullname;
               
            }
           
            $jsonData =(json_encode($result1));
            echo '{';
            echo'"success": true,';
            echo '"data":';
            echo $jsonData;
            //echo '';
            echo '}';
         
           
             // Send New  password code starts here...        
        $mailid=$emailid;
        $mail = new PHPMailer\PHPMailer(); //create
            
        $mail->isSMTP();
        //$mail->SMTPDebug = 2;
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPAuth = true;
        $mail->Username = 'test@gmail.com';
        $mail->Password = 'test';
        $mail->From = $mailid;
        $mail->FromName = 'TestMail';
        $mail->addAddress($mailid);
        //$mail->addAttachment($filepath);
        $mail->addReplyTo('test@gmail.com');
        $mail->WordWrap = 50;

             $BodyContent = "Dear $emp_fullname, Please use this token $newpassword to update the password                 
             Sent On : $currentTime";
            

             $mail->Subject = "New Token -$emp_fullname";
             $mail->Body    = $BodyContent;
                
             $mail->Message =''; 
             
             if(!$mail->send()) {
                 
               echo 'Message could not be sent.';
                
                echo 'Mailer Error: ' . $mail->ErrorInfo;
              exit;
             } 

        }else{
            $response = [
                'success'=> false,
                'error' =>'Invalid Email Address',
            ];
        return response()->json($response);
    }
    return redirect()->intended($this->redirectToChange);     
   }
  public function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}
//Get getempgallery  List//
public function getempgallery(Request $request)
{
    try{                   
        
        //if(!$user = JWTAuth::parseToken()->authenticate()){
        //    return response()->json(['msg' => 'user not found'],404);
      //  }
       $emp_id =Session::get('emp_id');

         $result = DB::table('gallery')
        ->select('photoid','emp_id','photo_name')
        ->where('emp_id', $emp_id)
        ->get();

        $completepath='http://127.0.0.1:8000/images/';

        foreach($result as $rowdt) {
            $photoid = $rowdt->photoid;
            $emp_id = $rowdt->emp_id;
            $photo_name = $rowdt->photo_name;
            $photo_name =$completepath.$photo_name;// $rowdt->photo_name;
            $rowdt->photo_name=$photo_name;
             $photo_name =$rowdt->photo_name;
          
        }//echo $result;
        return view('dashboard')->with("result",$result);
               
        }
        catch(TokenInvalidException $e){
         $response = [
                'success'=> false,
                'token' =>'Token Invalid',
                ];
            return response()->json($response,402);    
        }
        catch (TokenExpiredException $e){
            $rows1['token']=false;//$rows['storename'];//storename
            $jsonData =(json_encode($rows1));
            
            $jsonData =(json_encode($rows1));
            echo '{';
            echo'"success": true,';
            echo '"data": [';
            echo $jsonData;
            echo ']';
            echo '}';      
        }
        catch(JWTException $e){
        $response = [
            'success'=> false,
            'token' =>'Data Not Found',
                    ];
            return response()->json($response,405); 
        }
}

public function deleteimage($photoid){

    try{                   
        
        //if(!$user = JWTAuth::parseToken()->authenticate()){
        //    return response()->json(['msg' => 'user not found'],404);
      //  }
      $result = DB::table('gallery')
      ->select('photo_name')
      ->where('photoid', $photoid)
      ->get();
      foreach($result as $rowdt) {
        $photo_name = $rowdt->photo_name;
      }
      $target_dir = public_path('images/');
      $target_file = $target_dir . $photo_name;
      unlink($target_file);

        $result = DB::connection('mysql')->table('gallery')->where('photoid', $photoid)->delete();
        
        echo "File Successfully Delete."; 
        echo "Success";   
        return redirect()->intended($this->redirectTo); 
               
        }
        catch(TokenInvalidException $e){
         $response = [
                'success'=> false,
                'token' =>'Token Invalid',
                ];
            return response()->json($response,402);    
        }
        catch (TokenExpiredException $e){
            $rows1['token']=false;//$rows['storename'];//storename
            $jsonData =(json_encode($rows1));
            
            $jsonData =(json_encode($rows1));
            echo '{';
            echo'"success": true,';
            echo '"data": [';
            echo $jsonData;
            echo ']';
            echo '}';      
        }
        catch(JWTException $e){
        $response = [
            'success'=> false,
            'token' =>'Data Not Found',
                    ];
            return response()->json($response,405); 
        }

}

public function postimage(Request $request)
{
        $target_dir = public_path('images/');
        $url = $_SERVER['REQUEST_URI']; //returns the current URL
        $parts = explode('/',$url);
        $dir = "http://".$_SERVER['SERVER_NAME'];

        for ($i = 0; $i < count($parts) - 1; $i++) {
        $dir .= $parts[$i] . "/";
        }
        
        $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

        if(!isset($_FILES["selectFile"])){

            echo "ERROR: no image revived";
            $target_file='Hello world';

            die();
        }
        $target_file = $target_dir . basename($_FILES["selectFile"]["name"]);

        $imagename=($_FILES["selectFile"]["name"]);
        // $imaid=($_FILES["selectFile"]["id"]);
        $emp_id =Session::get('emp_id');
        
        // $emp_id = substr($imagename, 0, strrpos($imagename, "."));
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
        // Check if image file is a actual image or fake image
        if(isset($_POST["submit"])) {
            
            $check = getimagesize($_FILES["selectFile"]["tmp_name"]);
            if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            
            } else {
                echo "File is not an image.";
                $uploadOk = 0;
                
            }
            
        }
    
        // Check if file already exists
        if (file_exists($target_file)) {
            echo "Sorry, file already exists.";
            $uploadOk = 0;
            
        } 
        // Check file size
        $size=$_FILES["selectFile"]["size"];
        //echo $size.'size';
        //if ($_FILES["selectFile"]["size"] > 500000) {
            if ($_FILES["selectFile"]["size"] > 3026107) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
            
        }
        // Allow certain file formats

        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            
            echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES["selectFile"]["tmp_name"], $target_file)) {
            
                $tempLocation     = $target_file;
                $targetFilePath   = $tempLocation;

                $userId = DB::connection('mysql')->table('gallery')->insertGetId(
                    array('emp_id' => $emp_id, 'photo_name' => $imagename
                        ));   
                
            } else {
                //echo $target_file;
                echo "Sorry, there was an error uploading your file.";
            }
            return redirect()->intended($this->redirectTo); 
        } 
    }
}
